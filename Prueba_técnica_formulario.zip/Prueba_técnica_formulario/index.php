
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Formulario Registro</title>
	<link rel="stylesheet" href="https://necolas.github.io/normalize.css/8.0.1/normalize.css">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet"> 
	<link rel="stylesheet" href="css/estilos.css">
	
	
</head>
<body>
	<main>
		<form action="guardar.php" method="POST" class="formulario" id="formulario">
			<!-- Grupo: Tipo documento -->
	
			<div class="formulario__grupo" id="grupo__tipoDocumento">
				<label for="tipoDocumento" class="formulario__label">Tipo Documento</label>
				<div class="formulario__grupo-input">
					<input type="tipoDocumento" class="formulario__input" name="tipoDocumento" id="tipoDocumento" placeholder="Cedula">
					<i class="formulario__validacion-estado fas fa-times-circle"></i>
				</div>
				<p class="formulario__input-error">solo puede contener letras.</p>
			</div>

			<!-- Grupo: documento -->
			<div class="formulario__grupo" id="grupo__documento">
				<label for="documento" class="formulario__label">Documento</label>
				<div class="formulario__grupo-input">
					<input type="text" class="formulario__input" name="documento" id="documento" placeholder="1090469288">
					<i class="formulario__validacion-estado fas fa-times-circle"></i>
				</div>
				<p class="formulario__input-error">el campo debe ser maximo de 20 dígitos.</p>
			</div>

			<!-- Grupo: nombre -->
			<div class="formulario__grupo" id="grupo__nombre">
				<label for="nombre" class="formulario__label">Nombre</label>
				<div class="formulario__grupo-input">
					<input type="nombre" class="formulario__input" name="nombre" id="nombre" placeholder="Camilo Aldana">
					<i class="formulario__validacion-estado fas fa-times-circle"></i>
				</div>
				<p class="formulario__input-error">solo puede contener letras.</p>
			</div>

			<!-- Grupo: telefono -->
			<div class="formulario__grupo" id="grupo__telefono">
				<label for="telefono" class="formulario__label">Telefono</label>
				<div class="formulario__grupo-input">
					<input type="telefono" class="formulario__input" name="telefono" id="telefono" placeholder="0000000000">
					<i class="formulario__validacion-estado fas fa-times-circle"></i>
				</div>
				<p class="formulario__input-error">solo puede contener numeros.</p>
			</div>

			<!-- Grupo: Correo Electronico -->
			<div class="formulario__grupo" id="grupo__correo">
				<label for="correo" class="formulario__label">Correo Electrónico</label>
				<div class="formulario__grupo-input">
					<input type="email" class="formulario__input" name="correo" id="correo" placeholder="correo@correo.com">
					<i class="formulario__validacion-estado fas fa-times-circle"></i>
				</div>
				<p class="formulario__input-error">El correo solo puede contener letras, numeros, puntos, guiones y guion bajo.</p>
			</div>

			<div class="formulario__mensaje" id="formulario__mensaje">
				<p><i class="fas fa-exclamation-triangle"></i> <b>Error:</b> Por favor rellena el formulario correctamente. </p>
			</div>

			<div class="formulario__grupo formulario__grupo-btn-enviar">
				<button type="submit" name= "enviar" class="formulario__btn" >Enviar</button>
				<p class="formulario__mensaje-exito" id="formulario__mensaje-exito">Formulario enviado exitosamente!</p>
			</div>
		</form>
		<?php
		include("guardar.php")
		?>
	</main>

	<script src="js/formulario.js"></script>
	<script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
</body>
</html>