<?php

include("cn.php");

if(isset($_POST['enviar'])){
    if(strlen($_POST['tipoDocumento']) >= 1 && strlen($_POST['documento']) >= 1 &&
    strlen($_POST['nombre']) >= 1 && strlen($_POST['telefono']) >= 1 &&
    strlen($_POST['correo']) >= 1  ) {
        $tipoDocumento = strip_tags($_POST['tipoDocumento']); 
        $documento = strip_tags($_POST['documento']);
        $nombre = strip_tags($_POST['nombre']);
        $telefono = strip_tags($_POST['telefono']);
        $correo = strip_tags($_POST['correo']);

        $insertar = "INSERT INTO usuarios(tipoDocumento, documento, nombre, telefono, correo) VALUES
        ('$tipoDocumento','$documento','$nombre','$telefono','$correo')";

        $resultado = mysqli_query($conex, $insertar);
    } 
}


 
?>
