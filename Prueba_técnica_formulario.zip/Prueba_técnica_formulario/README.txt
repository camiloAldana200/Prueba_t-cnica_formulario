lenguajes 
JavaScript
css
PHP 8.0.3

los iconos se obtuvieron de fontawesome

la base de datos que se utilizo fue MySQL.

La solución esta funcionada de por parte del Frontend, no logre conectar la base de datos Backend por falta de tiempo.